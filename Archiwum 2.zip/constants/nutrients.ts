export interface NutrientMeta {
  label: string;
  unit: string;
  rda_f?: number; // RDA dla kobiet
  rda_m?: number; // RDA dla mężczyzn
  category: 'macro' | 'vitamin' | 'mineral' | 'carotenoid' | 'phyto' | 'other';
}

export const NUTRIENTS: Record<string, NutrientMeta> = {
  // Makro
  calories:               { label: 'Kalorie',              unit: 'kcal', category: 'macro' },
  protein:                { label: 'Białko',               unit: 'g',    category: 'macro' },
  fat:                    { label: 'Tłuszcze',             unit: 'g',    category: 'macro' },
  carbs:                  { label: 'Węglowodany',          unit: 'g',    category: 'macro' },
  fiber:                  { label: 'Błonnik',              unit: 'g',    rda_f: 25,   rda_m: 38,   category: 'macro' },
  sugar_g:                { label: 'Cukry',                unit: 'g',    category: 'macro' },
  water_g:                { label: 'Woda',                 unit: 'g',    rda_f: 2700, rda_m: 3700, category: 'macro' },

  // Tłuszcze szczegółowe
  saturated_fat_g:        { label: 'Tłuszcze nasycone',   unit: 'g',    category: 'macro' },
  monounsaturated_fat_g:  { label: 'Tłuszcze jednonienasycone', unit: 'g', category: 'macro' },
  polyunsaturated_fat_g:  { label: 'Tłuszcze wielonienasycone', unit: 'g', category: 'macro' },
  omega3_g:               { label: 'Omega-3',             unit: 'g',    rda_f: 1.1,  rda_m: 1.6,  category: 'macro' },
  omega6_g:               { label: 'Omega-6',             unit: 'g',    category: 'macro' },

  // Witaminy
  vitamin_a_ug:           { label: 'Witamina A',          unit: 'µg',  rda_f: 700,  rda_m: 900,  category: 'vitamin' },
  vitamin_b1_mg:          { label: 'Witamina B1',         unit: 'mg',  rda_f: 1.1,  rda_m: 1.2,  category: 'vitamin' },
  vitamin_b2_mg:          { label: 'Witamina B2',         unit: 'mg',  rda_f: 1.1,  rda_m: 1.3,  category: 'vitamin' },
  vitamin_b3_mg:          { label: 'Witamina B3',         unit: 'mg',  rda_f: 14,   rda_m: 16,   category: 'vitamin' },
  vitamin_b5_mg:          { label: 'Witamina B5',         unit: 'mg',  rda_f: 5,    rda_m: 5,    category: 'vitamin' },
  vitamin_b6_mg:          { label: 'Witamina B6',         unit: 'mg',  rda_f: 1.3,  rda_m: 1.3,  category: 'vitamin' },
  vitamin_b7_ug:          { label: 'Biotyna B7',          unit: 'µg',  rda_f: 30,   rda_m: 30,   category: 'vitamin' },
  vitamin_b9_ug:          { label: 'Folian B9',           unit: 'µg',  rda_f: 400,  rda_m: 400,  category: 'vitamin' },
  vitamin_b12_ug:         { label: 'Witamina B12',        unit: 'µg',  rda_f: 2.4,  rda_m: 2.4,  category: 'vitamin' },
  vitamin_c_mg:           { label: 'Witamina C',          unit: 'mg',  rda_f: 75,   rda_m: 90,   category: 'vitamin' },
  vitamin_d_ug:           { label: 'Witamina D',          unit: 'µg',  rda_f: 15,   rda_m: 15,   category: 'vitamin' },
  vitamin_e_mg:           { label: 'Witamina E',          unit: 'mg',  rda_f: 15,   rda_m: 15,   category: 'vitamin' },
  vitamin_k1_ug:          { label: 'Witamina K1',         unit: 'µg',  rda_f: 90,   rda_m: 120,  category: 'vitamin' },
  vitamin_k2_ug:          { label: 'Witamina K2',         unit: 'µg',  rda_f: 90,   rda_m: 120,  category: 'vitamin' },

  // Minerały
  calcium_mg:             { label: 'Wapń',                unit: 'mg',  rda_f: 1000, rda_m: 1000, category: 'mineral' },
  iron_mg:                { label: 'Żelazo',              unit: 'mg',  rda_f: 18,   rda_m: 8,    category: 'mineral' },
  magnesium_mg:           { label: 'Magnez',              unit: 'mg',  rda_f: 310,  rda_m: 400,  category: 'mineral' },
  phosphorus_mg:          { label: 'Fosfor',              unit: 'mg',  rda_f: 700,  rda_m: 700,  category: 'mineral' },
  potassium_mg:           { label: 'Potas',               unit: 'mg',  rda_f: 2600, rda_m: 3400, category: 'mineral' },
  sodium_mg:              { label: 'Sód',                 unit: 'mg',  category: 'mineral' },
  zinc_mg:                { label: 'Cynk',                unit: 'mg',  rda_f: 8,    rda_m: 11,   category: 'mineral' },
  copper_mg:              { label: 'Miedź',               unit: 'mg',  rda_f: 0.9,  rda_m: 0.9,  category: 'mineral' },
  manganese_mg:           { label: 'Mangan',              unit: 'mg',  rda_f: 1.8,  rda_m: 2.3,  category: 'mineral' },
  selenium_ug:            { label: 'Selen',               unit: 'µg',  rda_f: 55,   rda_m: 55,   category: 'mineral' },
  iodine_ug:              { label: 'Jod',                 unit: 'µg',  rda_f: 150,  rda_m: 150,  category: 'mineral' },
  choline_mg:             { label: 'Cholina',             unit: 'mg',  rda_f: 425,  rda_m: 550,  category: 'mineral' },

  // Karotenoidy
  beta_carotene_ug:       { label: 'Beta-karoten',        unit: 'µg',  category: 'carotenoid' },
  lutein_zeaxanthin_ug:   { label: 'Luteina + zeaksantyna', unit: 'µg', rda_f: 6000, rda_m: 6000, category: 'carotenoid' },
  lycopene_ug:            { label: 'Likopen',             unit: 'µg',  category: 'carotenoid' },

  // Fitoskładniki
  polyphenols_mg:         { label: 'Polifenole',          unit: 'mg',  category: 'phyto' },
  quercetin_mg:           { label: 'Kwercetyna',          unit: 'mg',  category: 'phyto' },
  anthocyanins_mg:        { label: 'Antocyjany',          unit: 'mg',  category: 'phyto' },
  chlorogenic_acid_mg:    { label: 'Kwas chlorogenowy',   unit: 'mg',  category: 'phyto' },

  // Inne
  betaine_mg:             { label: 'Betaina',             unit: 'mg',  rda_f: 500,  rda_m: 500,  category: 'other' },
  caffeine_mg:            { label: 'Kofeina',             unit: 'mg',  category: 'other' },
  coenzyme_q10_mg:        { label: 'Koenzym Q10',         unit: 'mg',  category: 'other' },
  carnitine_mg:           { label: 'Karnityna',           unit: 'mg',  category: 'other' },
  collagen_g:             { label: 'Kolagen',             unit: 'g',   category: 'other' },
};

// Wszystkie składniki pogrupowane kategoriami
export const DASHBOARD_NUTRIENTS = [
  // Makro rozszerzone
  'fiber',
  'sugar_g',
  'water_g',
  'saturated_fat_g',
  'monounsaturated_fat_g',
  'polyunsaturated_fat_g',
  'omega3_g',
  'omega6_g',
  // Witaminy
  'vitamin_a_ug',
  'vitamin_b1_mg',
  'vitamin_b2_mg',
  'vitamin_b3_mg',
  'vitamin_b5_mg',
  'vitamin_b6_mg',
  'vitamin_b7_ug',
  'vitamin_b9_ug',
  'vitamin_b12_ug',
  'vitamin_c_mg',
  'vitamin_d_ug',
  'vitamin_e_mg',
  'vitamin_k1_ug',
  'vitamin_k2_ug',
  // Minerały
  'calcium_mg',
  'iron_mg',
  'magnesium_mg',
  'phosphorus_mg',
  'potassium_mg',
  'sodium_mg',
  'zinc_mg',
  'copper_mg',
  'manganese_mg',
  'selenium_ug',
  'iodine_ug',
  'choline_mg',
  // Karotenoidy
  'beta_carotene_ug',
  'lutein_zeaxanthin_ug',
  'lycopene_ug',
  // Fitoskładniki
  'polyphenols_mg',
  'quercetin_mg',
  'anthocyanins_mg',
  'chlorogenic_acid_mg',
  // Inne
  'betaine_mg',
  'caffeine_mg',
  'coenzyme_q10_mg',
  'carnitine_mg',
  'collagen_g',
];
