import { NutrientValues } from '../types';
import { searchFood, getFoodByKey, calculateNutrients } from './nutrients';
import { ParsedFood } from './claude';
import { MealItem } from '../types';

export async function resolveMealItems(parsedFoods: ParsedFood[]): Promise<MealItem[]> {
  const items: MealItem[] = [];

  for (const food of parsedFoods) {
    const id = Math.random().toString(36).slice(2);

    // Najpierw spróbuj bezpośredniego lookup po kluczu (szablony używają kluczy)
    const directItem = getFoodByKey(food.name);
    if (directItem) {
      const nutrients = calculateNutrients(directItem.per_100g, food.weight_grams);
      items.push({
        id,
        name: directItem.name_pl,
        weight_grams: food.weight_grams,
        nutrients,
        confirmed: true,
        nutrient_key: food.name,
      });
      continue;
    }

    const results = searchFood(food.name);

    if (results.length > 0) {
      // Zawsze używaj najlepszego dopasowania z bazy
      const { key, item, score } = results[0];
      const nutrients = calculateNutrients(item.per_100g, food.weight_grams);
      items.push({
        id,
        name: item.name_pl,
        weight_grams: food.weight_grams,
        nutrients,
        confirmed: true,
        nutrient_key: key,
      });
    } else {
      // Brak dopasowania w bazie - wstaw puste wartości zamiast odpytywać Claude
      items.push({
        id,
        name: food.name,
        weight_grams: food.weight_grams,
        nutrients: {} as NutrientValues,
        confirmed: false,
      });
    }
  }

  return items;
}

export function sumNutrientValues(items: MealItem[]): NutrientValues {
  const total: NutrientValues = {};
  for (const item of items) {
    for (const [key, value] of Object.entries(item.nutrients)) {
      if (typeof value === 'number') {
        (total as any)[key] = ((total as any)[key] ?? 0) + value;
      }
    }
  }
  return total;
}
