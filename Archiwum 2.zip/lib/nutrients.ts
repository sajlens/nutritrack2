import { NutrientValues, FoodItem } from '../types';
import nutrientsDB from '../data/nutrients_db.json';

const DB = nutrientsDB as any;

// Normalizuje polskie znaki do ASCII
function normalize(str: string): string {
  return str
    .toLowerCase()
    .replace(/a/g, 'a').replace(/c/g, 'c').replace(/e/g, 'e')
    .replace(/l/g, 'l').replace(/n/g, 'n').replace(/o/g, 'o')
    .replace(/s/g, 's').replace(/z/g, 'z').replace(/x/g, 'z')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9 ]/g, '')
    .trim();
}

export function searchFood(query: string): Array<{ key: string; item: FoodItem; score: number }> {
  const q = normalize(query);
  const qWords = q.split(/\s+/).filter(w => w.length > 2);
  const results: Array<{ key: string; item: FoodItem; score: number }> = [];

  for (const [key, item] of Object.entries(DB.items) as [string, FoodItem][]) {
    const namePl = normalize(item.name_pl);
    let score = 0;

    if (namePl === q) score = 100;
    else if (namePl.startsWith(q)) score = 85;
    else if (namePl.includes(q)) score = 70;
    else if (qWords.length > 0) {
      const matchedWords = qWords.filter(w => namePl.includes(w));
      if (matchedWords.length > 0) {
        score = Math.round((matchedWords.length / qWords.length) * 60);
      }
    }

    if (score < 50 && item.aliases) {
      for (const alias of item.aliases) {
        const a = normalize(alias);
        if (a === q) { score = 90; break; }
        if (a.includes(q) || q.includes(a)) { score = Math.max(score, 55); break; }
        const matchedInAlias = qWords.filter(w => a.includes(w));
        if (matchedInAlias.length > 0) {
          score = Math.max(score, Math.round((matchedInAlias.length / qWords.length) * 50));
        }
      }
    }

    if (score > 0) results.push({ key, item, score });
  }

  return results.sort((a, b) => b.score - a.score).slice(0, 10);
}

export function getFoodByKey(key: string): FoodItem | null {
  return (DB.items[key] as FoodItem) ?? null;
}

export function calculateNutrients(per100g: NutrientValues, weightGrams: number): NutrientValues {
  const factor = weightGrams / 100;
  const result: NutrientValues = {};
  for (const [key, value] of Object.entries(per100g)) {
    if (typeof value === 'number') {
      (result as any)[key] = Math.round(value * factor * 1000) / 1000;
    }
  }
  return result;
}

export function sumNutrients(items: NutrientValues[]): NutrientValues {
  const total: NutrientValues = {};
  for (const item of items) {
    for (const [key, value] of Object.entries(item)) {
      if (typeof value === 'number') {
        (total as any)[key] = ((total as any)[key] ?? 0) + value;
      }
    }
  }
  for (const key of Object.keys(total)) {
    (total as any)[key] = Math.round((total as any)[key] * 1000) / 1000;
  }
  return total;
}
