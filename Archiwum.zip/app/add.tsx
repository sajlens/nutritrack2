import { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, ActivityIndicator, Alert, Modal, FlatList
} from 'react-native';
import { router } from 'expo-router';
import { parseMealDescription } from '../lib/claude';
import { resolveMealItems } from '../lib/calculations';
import { searchFood, calculateNutrients } from '../lib/nutrients';
import { useNutriStore } from '../store/useNutriStore';
import { MealItem } from '../types';
import { NUTRIENTS } from '../constants/nutrients';
import mealTemplates from '../data/meal_templates.json';

export default function AddMeal() {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [items, setItems] = useState<MealItem[]>([]);
  const [step, setStep] = useState<'input' | 'confirm'>('input');
  const [searchModal, setSearchModal] = useState<{ visible: boolean; itemId: string }>({ visible: false, itemId: '' });
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [templatesModal, setTemplatesModal] = useState(false);
  const { addMeal } = useNutriStore();

  const handleParse = async () => {
    if (!input.trim()) return;
    setIsLoading(true);
    try {
      const parsed = await parseMealDescription(input);
      const resolved = await resolveMealItems(parsed);
      setItems(resolved);
      setStep('confirm');
    } catch (e) {
      Alert.alert('Blad', 'Nie udalo sie przetworzyc opisu. Sprobuj ponownie.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoadTemplate = async (template: any) => {
    setTemplatesModal(false);
    setIsLoading(true);
    try {
      const resolved = await resolveMealItems(template.items);
      setItems(resolved);
      setInput(template.name);
      setStep('confirm');
    } catch (e) {
      Alert.alert('Blad', 'Nie udalo sie zaladowac szablonu.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsLoading(true);
    try {
      await addMeal(input, items);
      setInput('');
      setItems([]);
      setStep('input');
      router.replace('/');
    } catch (e) {
      Alert.alert('Blad', 'Nie udalo sie zapisac posilku.');
    } finally {
      setIsLoading(false);
    }
  };

  const updateWeight = (id: string, newWeight: string) => {
    const w = parseFloat(newWeight);
    if (isNaN(w)) return;
    setItems(prev => prev.map(item => {
      if (item.id !== id) return item;
      const nutrientKey = item.nutrient_key;
      if (nutrientKey) {
        const results = searchFood(item.name);
        const found = results.find(r => r.key === nutrientKey) || results[0];
        if (found) {
          const nutrients = calculateNutrients(found.item.per_100g, w);
          return { ...item, weight_grams: w, nutrients };
        }
      }
      return { ...item, weight_grams: w };
    }));
  };

  const openSearch = (itemId: string, currentName: string) => {
    setSearchQuery(currentName);
    const results = searchFood(currentName);
    setSearchResults(results);
    setSearchModal({ visible: true, itemId });
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query.trim().length < 2) { setSearchResults([]); return; }
    setSearchResults(searchFood(query));
  };

  const selectFood = (result: any) => {
    const { itemId } = searchModal;
    setItems(prev => prev.map(item => {
      if (item.id !== itemId) return item;
      const nutrients = calculateNutrients(result.item.per_100g, item.weight_grams);
      return { ...item, name: result.item.name_pl, nutrients, nutrient_key: result.key };
    }));
    setSearchModal({ visible: false, itemId: '' });
    setSearchQuery('');
    setSearchResults([]);
  };

  if (step === 'confirm') {
    return (
      <ScrollView style={styles.container}>
        <Text style={styles.heading}>Potwierdz posilek</Text>
        <Text style={styles.subheading}>{input}</Text>

        {items.map(item => (
          <View key={item.id} style={styles.itemCard}>
            <View style={styles.itemHeader}>
              <Text style={styles.itemName}>{item.name}</Text>
              <TouchableOpacity style={styles.changeBtn} onPress={() => openSearch(item.id, item.name)}>
                <Text style={styles.changeBtnText}>zmien</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.weightRow}>
              <TextInput
                style={styles.weightInput}
                value={String(item.weight_grams)}
                onChangeText={v => updateWeight(item.id, v)}
                keyboardType="numeric"
              />
              <Text style={styles.weightUnit}>g</Text>
            </View>
            <View style={styles.itemNutrients}>
              {(['calories', 'protein', 'fat', 'carbs'] as const).map(key => (
                <Text key={key} style={styles.itemNutrient}>
                  {NUTRIENTS[key].label}: {Math.round((item.nutrients as any)[key] ?? 0)}{NUTRIENTS[key].unit}
                </Text>
              ))}
            </View>
          </View>
        ))}

        <View style={styles.buttonRow}>
          <TouchableOpacity style={styles.btnSecondary} onPress={() => setStep('input')}>
            <Text style={styles.btnSecondaryText}>Wróc</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.btnPrimary} onPress={handleSave} disabled={isLoading}>
            {isLoading ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnPrimaryText}>Zapisz</Text>}
          </TouchableOpacity>
        </View>

        <Modal visible={searchModal.visible} animationType="slide" presentationStyle="pageSheet">
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Zmien skladnik</Text>
              <TouchableOpacity onPress={() => setSearchModal({ visible: false, itemId: '' })}>
                <Text style={styles.modalClose}>Anuluj</Text>
              </TouchableOpacity>
            </View>
            <TextInput
              style={styles.searchInput}
              value={searchQuery}
              onChangeText={handleSearch}
              placeholder="Szukaj produktu..."
              autoFocus
            />
            <FlatList
              data={searchResults}
              keyExtractor={item => item.key}
              renderItem={({ item }) => (
                <TouchableOpacity style={styles.searchResult} onPress={() => selectFood(item)}>
                  <Text style={styles.searchResultName}>{item.item.name_pl}</Text>
                  <Text style={styles.searchResultMeta}>
                    {Math.round(item.item.per_100g.calories ?? 0)} kcal / 100g · dopasowanie: {item.score}%
                  </Text>
                </TouchableOpacity>
              )}
              ListEmptyComponent={
                <Text style={styles.searchEmpty}>
                  {searchQuery.length >= 2 ? 'Brak wynikow.' : 'Wpisz min. 2 znaki.'}
                </Text>
              }
            />
          </View>
        </Modal>
      </ScrollView>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Co zjadlas?</Text>
      <Text style={styles.hint}>
        Opisz posilek naturalnie lub wybierz z ulubionych.
      </Text>
      <TextInput
        style={styles.textArea}
        value={input}
        onChangeText={setInput}
        placeholder="Opisz posilek..."
        multiline
        numberOfLines={4}
        textAlignVertical="top"
      />
      <View style={styles.buttonRow}>
        <TouchableOpacity
          style={styles.btnSecondary}
          onPress={() => setTemplatesModal(true)}
        >
          <Text style={styles.btnSecondaryText}>Ulubione</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.btnPrimary, !input.trim() && styles.btnDisabled]}
          onPress={handleParse}
          disabled={isLoading || !input.trim()}
        >
          {isLoading ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnPrimaryText}>Analizuj</Text>}
        </TouchableOpacity>
      </View>

      <Modal visible={templatesModal} animationType="slide" presentationStyle="pageSheet">
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Ulubione posilki</Text>
            <TouchableOpacity onPress={() => setTemplatesModal(false)}>
              <Text style={styles.modalClose}>Zamknij</Text>
            </TouchableOpacity>
          </View>
          <FlatList
            data={mealTemplates as any[]}
            keyExtractor={item => item.id}
            renderItem={({ item }) => (
              <TouchableOpacity style={styles.templateItem} onPress={() => handleLoadTemplate(item)}>
                <Text style={styles.templateName}>{item.name}</Text>
                <Text style={styles.templateMeta}>{item.items.length} skladnikow</Text>
              </TouchableOpacity>
            )}
          />
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9fafb', padding: 16 },
  heading: { fontSize: 22, fontWeight: '700', color: '#111827', marginBottom: 8 },
  subheading: { fontSize: 14, color: '#6b7280', marginBottom: 16 },
  hint: { fontSize: 14, color: '#6b7280', marginBottom: 16, lineHeight: 20 },
  textArea: {
    backgroundColor: '#fff', borderRadius: 12, padding: 16,
    fontSize: 16, borderWidth: 1, borderColor: '#e5e7eb',
    minHeight: 120, marginBottom: 16,
  },
  itemCard: {
    backgroundColor: '#fff', borderRadius: 12, padding: 16,
    marginBottom: 10, borderWidth: 1, borderColor: '#e5e7eb',
  },
  itemHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  itemName: { fontSize: 15, fontWeight: '600', color: '#111827', flex: 1 },
  changeBtn: { backgroundColor: '#f3f4f6', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  changeBtnText: { fontSize: 12, color: '#374151' },
  weightRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 8 },
  weightInput: {
    borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8,
    padding: 6, width: 60, textAlign: 'center', fontSize: 14,
  },
  weightUnit: { fontSize: 13, color: '#6b7280' },
  itemNutrients: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  itemNutrient: { fontSize: 12, color: '#6b7280', backgroundColor: '#f3f4f6', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  buttonRow: { flexDirection: 'row', gap: 12, marginBottom: 8 },
  btnPrimary: { flex: 1, backgroundColor: '#16a34a', borderRadius: 12, padding: 16, alignItems: 'center' },
  btnPrimaryText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  btnSecondary: { flex: 1, backgroundColor: '#e5e7eb', borderRadius: 12, padding: 16, alignItems: 'center' },
  btnSecondaryText: { color: '#374151', fontSize: 16, fontWeight: '600' },
  btnDisabled: { opacity: 0.5 },
  modalContainer: { flex: 1, backgroundColor: '#f9fafb' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  modalTitle: { fontSize: 17, fontWeight: '600', color: '#111827' },
  modalClose: { fontSize: 16, color: '#6b7280' },
  searchInput: { margin: 16, backgroundColor: '#fff', borderRadius: 12, padding: 14, fontSize: 16, borderWidth: 1, borderColor: '#e5e7eb' },
  searchResult: { backgroundColor: '#fff', padding: 16, borderBottomWidth: 1, borderBottomColor: '#f3f4f6' },
  searchResultName: { fontSize: 15, color: '#111827', marginBottom: 2 },
  searchResultMeta: { fontSize: 12, color: '#9ca3af' },
  searchEmpty: { textAlign: 'center', color: '#9ca3af', marginTop: 40, fontSize: 14 },
  templateItem: { backgroundColor: '#fff', padding: 16, borderBottomWidth: 1, borderBottomColor: '#f3f4f6' },
  templateName: { fontSize: 16, fontWeight: '600', color: '#111827', marginBottom: 2 },
  templateMeta: { fontSize: 12, color: '#9ca3af' },
});
